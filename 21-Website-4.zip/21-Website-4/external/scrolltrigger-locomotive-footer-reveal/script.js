gsap.registerPlugin(ScrollTrigger);

const pageContainer = document.querySelector(".scroller");





   

////////////////////////////////////
////////////////////////////////////
window.addEventListener("load", function () {
    
gsap.set('.footer-holder', { yPercent: -50 })

let uncover = gsap.timeline({ paused:true })

uncover
.to('.footer-holder', { yPercent: 0, ease: 'none' });    


  let pinBoxes = document.querySelectorAll(".pin-wrap > *");
  let pinWrap = document.querySelector(".pin-wrap");
  let pinWrapWidth = pinWrap.offsetWidth;
  let horizontalScrollLength = pinWrapWidth - window.innerWidth;
  console.log('width==='+ window.outerWidth)

  // Pinning and horizontal scrolling

  gsap.to(".pin-wrap", {
    scrollTrigger: {
    // scroller: pageContainer, //locomotive-scroll
      scrub: true,
      trigger: "#sectionPin",
      pin: true,
      // anticipatePin: 1,
      start: "top top",
      end: pinWrapWidth
    },
    x: -horizontalScrollLength,
    ease: "none"
  });
    
 
    
gsap.to(".intro-gp", {
    scrollTrigger: {
     // scroller: pageContainer, //locomotive-scroll
      trigger: '.intro-marker',
      start: 'left left',
      scrub: true,
      onLeave: startIntroAni,
      onLeaveBack: endIntroAni
    },
    yPercent: 0,
    ease: "none"
  }) 
    

 gsap.to(".email-holder", {
    scrollTrigger: {
     // scroller: pageContainer, //locomotive-scroll
      trigger: '.email-holder .subtitle',

     /*   start:'+=255%',*/
        start: '+=' + window.outerWidth/1.5,
        end: '+=' + window.outerWidth,
        marker:true,
      /*end:'+=485%',*/
      scrub: true,
      onEnter: startEmailAni,
     /* onEnterBack: startEmailAni,
      onLeave: endEmailAni,
      onLeaveBack: endEmailAni*/
    },
    yPercent: 0,
    ease: "none"
  })
    
 gsap.to(".address-holder", {
    scrollTrigger: {
     // scroller: pageContainer, //locomotive-scroll
      trigger: '.panel',
      start: '+=1425%',
      end:'+=1655%',
      scrub: true,
      onEnter: startAddressAni,
      onEnterBack: startAddressAni,
      onLeave: endAddressAni,
      onLeaveBack: endAddressAni
    },
    yPercent: 0,
    ease: "none"
  })
    
  gsap.to(".footer-holder", {
    scrollTrigger: {
     // scroller: pageContainer, //locomotive-scroll
      trigger: '.conclusion',
      start: 'bottom bottom',
      end: '+=75%',
      animation: uncover,
      scrub: true,
      onEnter: startFooterAni,
      onEnterBack: endFooterAni
    },
    yPercent: 0,
    ease: "none"
  })
    
/*  gsap.to(".address-gp", {
    scrollTrigger: {
      scroller: pageContainer, //locomotive-scroll
      trigger: '.subtitle',
      start: 'left left',
      end: 'righ rightt',
      pin:'#pin-subtitle',
      scrub: true
    },
    yPercent: 0,
    ease: "none"
  })*/
    
  /*  ScrollTrigger.create({
      trigger: ".address-gp",
      start: "left left", 
     end:'right right',
      pin: "#pin-subtitle"
    });*/
    
    
     function startIntroAni(e){
        console.log(' startIntroAni');
        // WHEN LEAVE INTRO SCREEN
        $('.intro-txt video').hide();
        $('.intro-txt video, .slogan-gp.black .intro-txt2').removeClass('show');//unset the txt bg 
        $('.intro-black-overlay').addClass('scroll-left');
        $('.slogan-gp.white').toggleClass('show'); // clip rect for the slogan when swipe
        //$('#intro').toggleClass('show');// chg bg to black to fill the holde
         
         endEmailAni();
       
    } 
    
      function endIntroAni(e){
        console.log(' endIntroAni');
        $('.intro-black-overlay').removeClass('scroll-left');
        $('.slogan-gp.white').removeClass('show');
       // $('#intro').removeClass('show');
       /* $('.intro-txt video').hide();*/
       
          //detect if black overlay already scroll left then only show vdeo
        $('#intro .intro-black-overlay').on("transitionend", function(event) {
            console.log('END')
            if($('.intro-black-overlay').hasClass('scroll-left') == false){
                console.log('IN')
                $('.intro-txt video, .slogan-gp.black .intro-txt2').addClass('show');
                $('.intro-txt video').show();
            }
        })
    } 
    
    function startEmailAni(e){
        console.log(' startEmailAni');
        //$('.pin-subtitle').removeClass('show');
        $('.subtitle').toggleClass('show');
         
        $('.ex1').textyleF();
        $('.ex2').textyleF({
              duration : 1000,
              delay : 200,
              easing : 'cubic-bezier(0.77, 0, 0.175, 1)',
              callback : function(){
                $(this).css({
                  color : '#f2085a',
                  transition : '1s',
                });
          }
        });
        
        $('.email-holder .ex2').on("transitionend", function(event) {
           /* console.log('ex2 END')*/
               $('.paper-fly-holder').addClass('fly');
        })
        
        $('.email-holder .paper-fly-holder').on("transitionend", function(event) {
            console.log('FLY END')
             $('.js-scene').addClass('is-over');
               $('.paper-fly-holder').fadeOut( "fast", function() {
                // Animation complete.
                   $('.email-holder .form-holder').hide();
                   $('.paper-fly-holder').removeClass('fly');
                  
                   // $('.email-holder .subtitle').hide();
              }); 
        })
        
        $('.paper-fly-holder').on("transitionstart ", function(event) {
           
            var matrix = $('.paper-fly-holder').css('transform').replace(/[^0-9\-.,]/g, '').split(',');
            var x = matrix[12] || matrix[4];
             console.log('FLY RUN =='+ x)
            
           
        })
        
        $('.email-holder .js-scene').on("transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd", function(event) {
           /* console.log('SPLIT END');*/
             $('.email-holder .form-holder').fadeIn( "slow")
             if($('.email-holder .js-scene').hasClass('is-over') == true){
                 $('.email-holder').addClass('chg-color');
             }  
        })
        
  /*      $('.paper-fly-holder').toggleClass('fly');
        clearTimeout(delayTime)
        var delayTime = setTimeout(function() { 
             $('.js-scene').toggleClass('is-over');
             $('.email-holder').fadeIn();
             $('.email-holder').toggleClass('chg-color');
        }, 2500);*/
       

    } 
    
    function endEmailAni(e){
        console.log(' endEmailAni');
        
        //reset form holder bg color 
        $('.email-holder').removeClass('chg-color');
        // reset split pane
        $('.js-scene').removeClass('is-over');
        //reset paper fly animmation
        $('.paper-fly-holder').removeClass('fly');
        $('.paper-fly-holder').show();
        
        // reset Subtitle animation
        $('.email-holder .subtitle').show();
        $('.email-holder .subtitle-1').html('Let\'s Talk');
        $('.email-holder .subtitle-2').html('With Us.')
        
         /* clearTimeout(delayExitTime)
        var delayExitTime = setTimeout(function() { 
            $('.js-scene').toggleClass('is-over');
            $('.email-holder').toggleClass('chg-color');
            $('.paper-fly-holder').toggleClass('fly');
        }, 2000);*/
       
        
    } 
    function startAddressAni(e){
        /*alert(' startAddressAni');*/
         $('.pin-subtitle').toggleClass('show');
    } 
    function endAddressAni(e){
       /* alert(' endAddressAni');*/
          $('.pin-subtitle').toggleClass('show');
    } 
     
    function startFooterAni(e){
         $('.pin-subtitle').toggleClass('show');
        gsap.timeline({ paused:true })
    } 
    
    function endFooterAni(e){
         $('.pin-subtitle').toggleClass('show');
       
    }  
    
    
    
/*let container = document.querySelector(".address-gp");
let tl = gsap.timeline({
  scrollTrigger: {
    pin: true,
    scrub: 1,
    trigger: container,
    end: () => `+=${container.scrollWidth - document.documentElement.clientWidth + container.offsetWidth}`
  },
  defaults: { ease: "none", duration: 1 }
});

tl.to(".parallax", { x: 300 })
  .to(".panel", {
      x: () => `+=${-(container.scrollWidth - document.documentElement.clientWidth)}`
    })*/

 // ScrollTrigger.addEventListener("refresh", () => scroller.update()); //locomotive-scroll

  ScrollTrigger.refresh();
});