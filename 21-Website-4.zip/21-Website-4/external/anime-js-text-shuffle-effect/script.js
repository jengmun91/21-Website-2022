const random_char = () => {
  const possible = "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~" +
  "0123456789" +
  "ABCDEFGHIJKLMNOPQRSTUVWXYZ" +
  "abcdefghijklmnopqrstuvwxyz";
  return possible.charAt(Math.floor(Math.random() * possible.length));
};

const mask = (chars, progress) => {
  const masked = [];

  for (let i = 0; i < chars.length; i++) {
    const position = (i + 1) / chars.length;
    if (position > progress) {
      masked.push(random_char());
    } else {
      masked.push(chars[i]);
    }
  }

  return masked.join('');
};

const shuffle = el => {
  const chars = el.textContent.split('');

  const params = {
    progress: 0 };


  const a = anime({
    targets: params,
    progress: 1,
    delay: 1000,
    duration: 500,
    easing: 'easeInQuad',
    update: () => {
      el.textContent = mask(chars, params.progress);
    },
    complete: () => {
      el.classList.add('completed');
    } });


  el.onclick = () => {
    el.classList.remove('completed');
    //a.restart();
  };
};


/*function animateGadgetTXT(){
    console.log('animateGadgetTXT')
    for (const el of document.querySelectorAll('.shuffle')) {
      shuffle(el);
    }
}*/
/*var delayTimer1;
var delayTimer2;
var delayTimer3;
var delayTimer4;

//delayTimer = setInterval(startShuffle, 2500);
delayTimer1 = setInterval(function() {
   startShuffle(1);
 }, 2500);

delayTimer2 = setInterval(function() {
   startShuffle(2);
 }, 3500);

delayTimer3 = setInterval(function() {
   startShuffle(3);
 }, 4500);

delayTimer4 = setInterval(function() {
   startShuffle(4);
 }, 6000);



function startShuffle(no){
    switch(no){
        case 1: clearInterval(delayTimer1);break;
        case 2: clearInterval(delayTimer2);break;
        case 3: clearInterval(delayTimer3);break;
        case 4: clearInterval(delayTimer4);break;
            
    }
    
    
    $('.shuffle'+no).show();
    for (const el of document.querySelectorAll('.shuffle'+no)) {
      shuffle(el);
    }
    $('.menu-'+ no +' .section-menu-desc').addClass('show')
}*/
